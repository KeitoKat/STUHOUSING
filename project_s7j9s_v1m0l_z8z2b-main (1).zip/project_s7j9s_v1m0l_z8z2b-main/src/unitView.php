<html>
    <head>
        <title style=" color: blue; "> Unit View </title>
    </head>

    <header class="navbar navbar-default navbar-static-top">

<!-- STYLE -->
<style>
.topnav {
overflow: hidden;
}

.topnav a {
float: left;
color: #3b322b;
text-align: center;
padding: 14px 16px;
text-decoration: none;
font-size: 17px;
}

.topnav a:hover {
background-color: #ddd;
color: black;
}

.topnav a.main {
background-color: #254038;
color: #f0fff0;
}

a.leftside {
float:right;
}

a.active {
text-decoration: underline;
}


</style>


<div class="container-fluid">
    <div class="navbar-header">
    <div class="topnav">
        <a class="main" href="unitSearch.php">Unit Search</a>
        <a class="active" href="unitManagement.php">Unit Management</a>
        <a href="profileSearcher.php">Profile Searcher</a>
        <a class="leftside" href="signin.php">Sign In</a>
    </div>
</div>

</header>

    <body>
        <h2 style=" color: blue; align: Center; ">Unit Details</h2>
        <?php
            $unitId = $_GET['unitID'];
            ConnectToDB();
            $result = executePlainSQL("SELECT NoBedrooms, NoBathrooms, Address, Furnished, LeaseTerm, Sublet, MoveInDate, AskingPrice
                FROM Unit
                WHERE UnitID = $unitId ");

            echo "<style>
            table {
                border-collapse: collapse;
            }
            th, td {
                padding: 10px;
            }
            th {
                background-color: #f2f2f2;
            }
            </style>";           

            echo "<table>\n";
            echo "<tr>\n";
            echo "<th>Variable</th>\n";
            echo "<th>Value</th>\n";
            echo "</tr>\n";

            while ($row = oci_fetch_array($result, OCI_ASSOC+OCI_RETURN_NULLS)) {
                foreach ($row as $variable => $value) {
                    echo "<tr>\n";
                    echo "<td>" . ($variable !== null ? htmlentities($variable, ENT_QUOTES) : "&nbsp;") . "</td>\n";
                    
                    // Format MoveInDate if it is the variable being processed
                    if ($variable === 'MoveInDate') {
                        $formattedDate = ($value !== null ? date('Y-m-d', strtotime($value)) : "&nbsp;");
                        echo "<td>" . htmlentities($formattedDate, ENT_QUOTES) . "</td>\n";
                    } else {
                        echo "<td>" . ($value !== null ? htmlentities($value, ENT_QUOTES) : "&nbsp;") . "</td>\n";
                    }
                    
                    echo "</tr>\n";
                }
            }
            
            echo "</table>\n";
        ?>

<body>
        <h2 style=" color: green; align: Center; ">Manager Details</h2>
        <?php
            ConnectToDB();
            $result = executePlainSQL( "SELECT m.ManagementID, m.Name, m.Email, m.PhoneNumber
            FROM Management m, Unit u
            WHERE m.ManagementID = u.ManagementID AND u.UnitID = " . $unitId
            );

            echo "<style>
            table {
                border-collapse: collapse;
            }
            th, td {
                padding: 10px;
            }
            th {
                background-color: #f2f2f2;
            }
            </style>";           

            echo "<table>\n";
            echo "<tr>\n";
            echo "<th>Variable</th>\n";
            echo "<th>Value</th>\n";
            echo "</tr>\n";

            while ($row = oci_fetch_array($result, OCI_ASSOC+OCI_RETURN_NULLS)) {
                foreach ($row as $variable => $value) {
                    echo "<tr>\n";
                    echo "<td>" . ($variable !== null ? htmlentities($variable, ENT_QUOTES) : "&nbsp;") . "</td>\n";
                    
                    // Format MoveInDate if it is the variable being processed
                    if ($variable === 'MoveInDate') {
                        $formattedDate = ($value !== null ? date('Y-m-d', strtotime($value)) : "&nbsp;");
                        echo "<td>" . htmlentities($formattedDate, ENT_QUOTES) . "</td>\n";
                    } else {
                        echo "<td>" . ($value !== null ? htmlentities($value, ENT_QUOTES) : "&nbsp;") . "</td>\n";
                    }
                    
                    echo "</tr>\n";
                }
            }
            
            echo "</table>\n";
        ?>

        <form method="GET" id="displayUnitInfo" name="displayUnitInfo" action="unitView.php">
            <input type="submit" value="Select to Display Interest in Unit" name="InterestedIn"></p>>
        </form>

        
        <?php
                function executePlainSQL($cmdstr) { //takes a plain (no bound variables) SQL command and executes it
                    //echo "<br>running ".$cmdstr."<br>";
                    global $db_conn, $success;
                    $statement = OCIParse($db_conn, $cmdstr);
                    //There are a set of comments at the end of the file that describe some of the OCI specific functions and how they work
                    if (!$statement) {
                        echo "<br>Cannot parse the following command: " . $cmdstr . "<br>";
                        $e = OCI_Error($db_conn); // For OCIParse errors pass the connection handle
                        echo htmlentities($e['message']);
                        $success = False;
                    }
        
                    $r = OCIExecute($statement, OCI_DEFAULT);
                    if (!$r) {
                        echo "<br>Cannot execute the following command: " . $cmdstr . "<br>";
                        $e = oci_error($statement); // For OCIExecute errors pass the statementhandle
                        echo htmlentities($e['message']);
                        $success = False;
                    }
                    return $statement;
                }
        ?>

        <?php
            $success = True; //keep track of errors so it redirects the page only if there are no errors
            $db_conn = NULL; // edit the login credentials in connectToDB()
            $show_debug_alert_messages = False; // set to True if you want alerts to show you which methods are being triggered (see how it is used in debugAlertMessage())

            function debugAlertMessage($message) {
                global $show_debug_alert_messages;
    
                if ($show_debug_alert_messages) {
                    echo "<script type='text/javascript'>alert('" . $message . "');</script>";
                }
            }
        ?>




        <?php
            function connectToDB() {
                global $db_conn;

                // Your username is ora_(CWL_ID) and the password is a(student number). For example,
                // ora_platypus is the username and a12345678 is the password.
                $db_conn = OCILogon("ora_kitachi", "a61086260", "dbhost.students.cs.ubc.ca:1522/stu");
                if ($db_conn) {
                    debugAlertMessage("Database is Connected");
                    return true;
                } else {
                    debugAlertMessage("Cannot connect to Database");
                    $e = OCI_Error(); // For OCILogon errors pass no handle
                    echo htmlentities($e['message']);
                    
                    return false;
                }
            }

            function disconnectFromDB() {
                global $db_conn;

                debugAlertMessage("Disconnect from Database");
                OCILogoff($db_conn);
            }

            function redirect($url) {
                header('Location: '.$url);
                die();
            }

            function executeBoundSQL($cmdstr, $list) { // Sometimes the same statement will be executed several times with different values for the variables involved in the query.
                // In this case you don't need to create the statement several times. Bound variables cause a statement to only be
                // parsed once and you can reuse the statement. This is also very useful in protecting against SQL injection.
                // See the sample code below for how this function is used 
    
                global $db_conn, $success;
                $statement = OCIParse($db_conn, $cmdstr);
    
                if (!$statement) {
                    echo "<br>Cannot parse the following command: " . $cmdstr . "<br>";
                    $e = OCI_Error($db_conn);
                    echo htmlentities($e['message']);
                    $success = False;
                }
    
                foreach ($list as $tuple) {
                    foreach ($tuple as $bind => $val) {
                        //echo $val;
                        //echo "<br>".$bind."<br>";
                        OCIBindByName($statement, $bind, $val);
                        unset ($val); //make sure you do not remove this. Otherwise $val will remain in an array object wrapper which will not be recognized by Oracle as a proper datatype
                    }
    
                    $r = OCIExecute($statement, OCI_DEFAULT);
                    if (!$r) {
                        echo "<br>Cannot execute the following command: " . $cmdstr . "<br>";
                        $e = OCI_Error($statement); // For OCIExecute errors, pass the statementhandle
                        echo htmlentities($e['message']);
                        echo "<br>";
                        $success = False;
                    }
                }
            }

            function handleInterest() {
                global $db_conn;

                echo "<br>  Interest Noted <br>";
            }

            // function handlePOSTRequest() {
            //     if (connectToDB()) {
            //         if (array_key_exists('InterestedIn', $_POST)) {
            //             handleInterest();
            //         }
            //     }
            //     disconnectFromDB();
            // }

            function handleGETRequest() {
                if (connectToDB()) {
                    if (array_key_exists('InterestedIn', $_GET)) {
                        handleInterest();
                    }
                    disconnectFromDB();
                }
            }

            if (isset($_GET['InterestedIn'])) {
                handleGETRequest();
            }

        ?>

	</body>
</html> 