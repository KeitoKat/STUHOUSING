<html>
    <head>
        <title style=" color: blue; "> Unit Management </title>
    </head>
    <body>
    <header class="navbar navbar-default navbar-static-top">

    <!-- STYLE -->
    <style>
.topnav {
  overflow: hidden;
}

.topnav a {
  float: left;
  color: #3b322b;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #254038;
  color: #f0fff0;
}

a.leftside {
  float:right;
}

</style>


    <div class="container-fluid">
        <div class="navbar-header">
        <div class="topnav">
            <a class="active" href="unitSearch.php">Unit Search</a>
            <a href="unitView.php">Unit View</a>
            <a href="unitManagement.php">Unit Management</a>
            <a href="profileSearcher.php">Profile Searcher</a>
            <a class="leftside" href="signin.php">Sign In</a>
        </div>
    </div>
    
  </header>
    
    </body>
</html>