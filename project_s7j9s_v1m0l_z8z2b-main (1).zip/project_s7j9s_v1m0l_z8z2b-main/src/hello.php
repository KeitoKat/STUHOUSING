<html>
	<p>If PHP is working, you will see "Hello World" below, followed by some PHP version information:</p><hr />
	<?php
		echo "Hello world";
		phpinfo();  // Print PHP version and config info
	?>
</html>