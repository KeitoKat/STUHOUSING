<html>
    <head>
        <title style=" color: blue; "> Profile Searcher </title>
    </head>

    <header class="navbar navbar-default navbar-static-top">

    <!-- STYLE -->
    <style>
.topnav {
  overflow: hidden;
}

.topnav a {
  float: left;
  color: #3b322b;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.main {
  background-color: #254038;
  color: #f0fff0;
}

a.leftside {
  float:right;
}

a.active {
    text-decoration: underline;
}


</style>


    <div class="container-fluid">
        <div class="navbar-header">
        <div class="topnav">
            <a class="main" href="unitSearch.php">Unit Search</a>
            <a href="unitManagement.php">Unit Management</a>
            <a class="active" href="profileSearcher.php">Profile Searcher</a>
            <a class="leftside" href="signin.php">Sign In</a>
        </div>
    </div>
    
  </header>

    <body>
        <h2 style=" color: blue; align: Center; ">Profile Searcher</h2>


        <?php
                ConnectToDB();
                echo ("Searchers who are interested in all units\n\n");

                $result = executePlainSQL("SELECT S.fullName
                FROM Searcher S
                WHERE NOT EXISTS (SELECT U.UnitID
                                FROM Unit U
                                WHERE NOT EXISTS (SELECT A.SearcherID
                                                    FROM Unit_Searcher A
                                                    WHERE U.UnitID = A.UnitID
                                                    AND A.SearcherID = S.SearcherID))
                                                    ");


                // $result = executePlainSQL($temp_result);

                if (!$result) {
                    echo ("ABC\n\n");
                    return;
                }
                echo ("DEF\n\n");

                echo "<table>\n";
                echo "<tr>\n";
                echo "<th>fullName</th>\n";
                echo "</tr>\n";
                

                while ($row = oci_fetch_array($result, OCI_ASSOC+OCI_RETURN_NULLS)) {
                    echo "<tr>\n";
                    echo "<td>" . ($row['FULLNAME'] !== null ? htmlentities($row['FULLNAME'], ENT_QUOTES) : "&nbsp;") . "</td>\n";
                    echo "</tr>\n";
                }

                echo "</table>\n";
        ?>

        <h2>Update Phone Number</h2>

            <form method="POST" action="profileSearcher.php"> <!--refresh page when submitted-->
                <input type="hidden" id="updateQueryRequest" name="updateQueryRequest">
                Old Phone Number: <input type="text" name="oldPhoneNumber"> <br /><br />
                New Phone Number: <input type="text" name="newPhoneNumber"> <br /><br />

                <input type="submit" value="Update" name="updateSubmit"></p>
        </form>


        


        <?php
        function displaySearcherData() {
            ConnectToDB();
            $result = executePlainSQL("SELECT searcherID, fullName
                FROM Searcher
            ");

            if (!$result) {
                echo "Error retrieving data from the database.";
                return;
            }

            echo "<table>\n";
            echo "<tr>\n";
            echo "<th>searcherID</th>\n";
            echo "<th>fullName</th>\n";
            echo "</tr>\n";

            while ($row = oci_fetch_array($result, OCI_ASSOC+OCI_RETURN_NULLS)) {
                echo "<tr>\n";
                echo "<td>" . ($row['SEARCHERID'] !== null ? htmlentities($row['SEARCHERID'], ENT_QUOTES) : "&nbsp;") . "</td>\n";
                echo "<td>" . ($row['FULLNAME'] !== null ? htmlentities($row['FULLNAME'], ENT_QUOTES) : "&nbsp;") . "</td>\n";
                echo "</tr>\n";
            }

            echo "</table>\n";
        }
        displaySearcherData();

        
        ?>
        <form method="GET" action="profileSearcher.php">
            Input searcher ID for more details : <input type="number" name="idSelected"  min="0"> <br /><br />
            <input type="submit" value="Select" name="idSelection"></p>
        <hr />

        <p>Search Results:</p>
        <?php
                function executePlainSQL($cmdstr) { //takes a plain (no bound variables) SQL command and executes it
                    //echo "<br>running ".$cmdstr."<br>";
                    global $db_conn, $success;
                    $statement = OCIParse($db_conn, $cmdstr);
                    //There are a set of comments at the end of the file that describe some of the OCI specific functions and how they work
                    if (!$statement) {
                        echo "<br>Cannot parse the following command: " . $cmdstr . "<br>";
                        $e = OCI_Error($db_conn); // For OCIParse errors pass the connection handle
                        echo htmlentities($e['message']);
                        $success = False;
                    }
        
                    $r = OCIExecute($statement, OCI_DEFAULT);
                    if (!$r) {
                        echo "<br>Cannot execute the following command: " . $cmdstr . "<br>";
                        $e = oci_error($statement); // For OCIExecute errors pass the statementhandle
                        echo htmlentities($e['message']);
                        $success = False;
                    }
                    return $statement;
                }
        ?>


        <?php
            $success = True; //keep track of errors so it redirects the page only if there are no errors
            $db_conn = NULL; // edit the login credentials in connectToDB()
            $show_debug_alert_messages = False; // set to True if you want alerts to show you which methods are being triggered (see how it is used in debugAlertMessage())

            function debugAlertMessage($message) {
                global $show_debug_alert_messages;
    
                if ($show_debug_alert_messages) {
                    echo "<script type='text/javascript'>alert('" . $message . "');</script>";
                }
            }
        ?>




        <?php
            function connectToDB() {
                global $db_conn;

                // Your username is ora_(CWL_ID) and the password is a(student number). For example,
                // ora_platypus is the username and a12345678 is the password.
                $db_conn = OCILogon("ora_kitachi", "a61086260", "dbhost.students.cs.ubc.ca:1522/stu");
                if ($db_conn) {
                    debugAlertMessage("Database is Connected");
                    return true;
                } else {
                    debugAlertMessage("Cannot connect to Database");
                    $e = OCI_Error(); // For OCILogon errors pass no handle
                    echo htmlentities($e['message']);
                    
                    return false;
                }
            }

            function disconnectFromDB() {
                global $db_conn;

                debugAlertMessage("Disconnect from Database");
                OCILogoff($db_conn);
            }

            function redirect($url) {
                header('Location: '.$url);
                die();
            }

            function executeBoundSQL($cmdstr, $list) { // Sometimes the same statement will be executed several times with different values for the variables involved in the query.
                // In this case you don't need to create the statement several times. Bound variables cause a statement to only be
                // parsed once and you can reuse the statement. This is also very useful in protecting against SQL injection.
                // See the sample code below for how this function is used 
    
                global $db_conn, $success;
                $statement = OCIParse($db_conn, $cmdstr);
    
                if (!$statement) {
                    echo "<br>Cannot parse the following command: " . $cmdstr . "<br>";
                    $e = OCI_Error($db_conn);
                    echo htmlentities($e['message']);
                    $success = False;
                }
    
                foreach ($list as $tuple) {
                    foreach ($tuple as $bind => $val) {
                        //echo $val;
                        //echo "<br>".$bind."<br>";
                        OCIBindByName($statement, $bind, $val);
                        unset ($val); //make sure you do not remove this. Otherwise $val will remain in an array object wrapper which will not be recognized by Oracle as a proper datatype
                    }
    
                    $r = OCIExecute($statement, OCI_DEFAULT);
                    if (!$r) {
                        echo "<br>Cannot execute the following command: " . $cmdstr . "<br>";
                        $e = OCI_Error($statement); // For OCIExecute errors, pass the statementhandle
                        echo htmlentities($e['message']);
                        echo "<br>";
                        $success = False;
                    }
                }
            }

            function handleSelection() {
                ConnectToDB();
                $idSearcherSelected = $_GET['idSelected'];
                $result2 = executePlainSQL("SELECT SearcherID, FullName, DateOfBirth, Email, PhoneNumber, CurrentAddress, ReasonForLeave, MonthlyIncome
                    FROM Searcher
                    WHERE searcherID = $idSearcherSelected
                ");
        

                if (!$result2) {
                    
                    return;
                }

                echo "<table>\n";

                while ($row = oci_fetch_array($result2, OCI_ASSOC+OCI_RETURN_NULLS)) {
                    foreach ($row as $column => $value) {
                        echo "<tr>\n";
                        echo "<td>$column</td>\n";
                        echo "<td>" . ($value !== null ? htmlentities($value, ENT_QUOTES) : "&nbsp;") . "</td>\n";
                        echo "</tr>\n";
                    }
                }

                echo "</table>\n";
            }

            function handleUpdateRequest() {
                global $db_conn;
    
                $old_PhoneNumber = $_POST['oldPhoneNumber'];
                $new_PhoneNumber = $_POST['newPhoneNumber'];
    
                // you need the wrap the old name and new name values with single quotations
                executePlainSQL("UPDATE Searcher SET PhoneNumber='" . $new_PhoneNumber . "' WHERE PhoneNumber='" . $old_PhoneNumber . "'");
                
                OCICommit($db_conn);
    
            }

            function handlePOSTRequest() {
                if (connectToDB()) {
                    if (array_key_exists('updateQueryRequest', $_POST)) {
                        handleUpdateRequest();
                    }
                }
                disconnectFromDB();
            }

            function handleGETRequest() {
                if (connectToDB()) {
                    if (array_key_exists('idSelection', $_GET)) {
                        handleSelection();
                    }
                    disconnectFromDB();
                }
            }
            
            if (isset($_POST['updateSubmit'])) {
                handlePOSTRequest();
            } else if (isset($_GET['idSelection'])) {
                handleGETRequest();
            }

        ?>

	</body>
</html> 