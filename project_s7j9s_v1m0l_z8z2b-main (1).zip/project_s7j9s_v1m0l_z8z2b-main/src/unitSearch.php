<html>
    <head>
        <link href='./unitSearch.css' rel='stylesheet'>
        <title style=" color: blue; "> Unit Search </title>
    </head>

    <header class="navbar navbar-default navbar-static-top">

    <!-- STYLE -->
    <style>
.topnav {
  overflow: hidden;
}

.topnav a {
  float: left;
  color: #3b322b;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.main {
  background-color: #254038;
  color: #f0fff0;
}

a.leftside {
  float:right;
}

a.active {
    text-decoration: underline;
}


</style>


    <div class="container-fluid">
        <div class="navbar-header">
        <div class="topnav">
            <a class="main active" href="unitSearch.php">Unit Search</a>
            <a href="unitManagement.php">Unit Management</a>
            <a href="profileSearcher.php">Profile Searcher</a>
            <a class="leftside" href="signin.php">Sign In</a>
        </div>
    </div>
    
  </header>

    <body>    
    <h2>Find your perfect unit!</h2>
        <div class="section1">
            <form class='searchForm' method="GET" action="unitSearch.php">
                <input type="hidden" id="displayUnitsRequest" name="displayUnitsRequest">
                <p>Maximum number of bedrooms:</p>
                <div>
                    <input type="radio" id="NoBedrooms1" name="NoBedrooms" value="1">
                    <label for="NoBedrooms1"> 1 </label><br>
                </div>
                <div>
                    <input type="radio" id="NoBedrooms2" name="NoBedrooms" value="2">
                    <label for="NoBedrooms2"> 2 </label><br>
                </div>
                <div>
                    <input type="radio" id="NoBedrooms3" name="NoBedrooms" value="3">
                    <label for="NoBedrooms3"> 3 </label><br>
                </div>
                <div>
                    <input type="radio" id="NoBedrooms4" name="NoBedrooms" value="4">
                    <label for="NoBedrooms4"> 4  </label><br>
                </div>
                <div>
                    <input type="radio" id="NoBedroomsMore" name="NoBedrooms" value="> 5">
                    <label for="NoBedroomsMore"> 5 or More </label><br> <br />
                </div>
    
                <p>Maximum Number of bathrooms:</p>
                <div>
                    <input type="radio" id="NoBathrooms1" name="NoBathrooms" value="1">
                    <label for="NoBathrooms1"> 1 </label><br>
                    </div>
                <div>
                    <input type="radio" id="NoBathrooms2" name="NoBathrooms" value="2">
                    <label for="NoBathrooms2"> 2 </label><br>
                </div>
                <div>
                    <input type="radio" id="NoBathrooms3" name="NoBathrooms" value="3">
                    <label for="NoBathrooms3"> 3 </label><br>
                </div>
                <div>
                    <input type="radio" id="NoBathrooms4" name="NoBathrooms" value="4">
                    <label for="NoBathrooms4"> 4  </label><br>
                </div>
                <div>
                    <input type="radio" id="NoBathroomsMore" name="NoBathrooms" value="> 5">
                    <label for="NoBathroomsMore"> 5 or More </label><br> <br />
                </div>
    
                <div>
                    <p>Price less than:</p><input id="priceField"  type="number" name="AskingPrice"  min="0"> 
                </div>
                <br>
                <input id="searchField" type="submit" value="Select" name="displayUnits">
            </form>
    
            <?php
                    function executePlainSQL($cmdstr) { //takes a plain (no bound variables) SQL command and executes it
                        //echo "<br>running ".$cmdstr."<br>";
                        global $db_conn, $success;
                        $statement = OCIParse($db_conn, $cmdstr);
                        //There are a set of comments at the end of the file that describe some of the OCI specific functions and how they work
                        if (!$statement) {
                            echo "<br>Cannot parse the following command: " . $cmdstr . "<br>";
                            $e = OCI_Error($db_conn); // For OCIParse errors pass the connection handle
                            echo htmlentities($e['message']);
                            $success = False;
                        }
            
                        $r = OCIExecute($statement, OCI_DEFAULT);
                        if (!$r) {
                            echo "<br>Cannot execute the following command: " . $cmdstr . "<br>";
                            $e = oci_error($statement); // For OCIExecute errors pass the statementhandle
                            echo htmlentities($e['message']);
                            $success = False;
                        }
                        return $statement;
                    }
    
                    function debugAlertMessage($message) {
                        global $show_debug_alert_messages;
            
                        if ($show_debug_alert_messages) {
                            echo "<script type='text/javascript'>alert('" . $message . "');</script>";
                        }
                    }
    
                    
                function connectToDB() {
                    global $db_conn;
    
                    // Your username is ora_(CWL_ID) and the password is a(student number). For example,
                    // ora_platypus is the username and a12345678 is the password.
                    $db_conn = OCILogon("ora_kitachi", "a61086260", "dbhost.students.cs.ubc.ca:1522/stu");
                    if ($db_conn) {
                        debugAlertMessage("Database is Connected");
                        return true;
                    } else {
                        debugAlertMessage("Cannot connect to Database");
                        $e = OCI_Error(); // For OCILogon errors pass no handle
                        echo htmlentities($e['message']);
                        return false;
                    }
                }
    
                function disconnectFromDB() {
                    global $db_conn;
    
                    debugAlertMessage("Disconnect from Database");
                    OCILogoff($db_conn);
                }
    
                function handleUpdateRequest() {
                    global $db_conn;
    
                    $old_name = $_POST['oldName'];
                    $new_name = $_POST['newName'];
    
                    // you need the wrap the old name and new name values with single quotations
                    executePlainSQL("UPDATE demoTable SET name='" . $new_name . "' WHERE name='" . $old_name . "'");
                    OCICommit($db_conn);
                }
            ?>
    
            <div class = "statistics">
                <p>Total number of Units Available</p>
                <?php 
                    ConnectToDB();
                    $query = "SELECT COUNT(*) FROM Unit";
                    $result = executePlainSQL($query);
                    $data = oci_fetch_row($result);
                    echo $data[0] ;
                    ?>
                <br>
                <p>Average price of units by number of bedrooms:</p>
                <?php 
                    ConnectToDB();
                    $query = 'SELECT NoBedrooms, AVG(AskingPrice) FROM Unit GROUP BY NoBedrooms';
                    $result = executePlainSQL($query);
                    echo '<br>';
                    while ($data = oci_fetch_row($result)) {
                        echo  "BHK: " . $data[0] . ", AvgPrice: " . $data[1] . "<br>";
                    }
                    echo $data;        
                    // $query = 'SELECT NoBedrooms, UnitID, AVERAGE(AskingPrice) FROM Unit GROUP BY NoBedrooms';
                ?>
                <br>
                <p>Lowest price above average cost based on lease term:</p>
                <?php 
                    ConnectToDB();
                    $query = 'SELECT u1.LeaseTerm, MIN(u1.AskingPrice)
                    FROM Unit u1
                    GROUP BY u1.LeaseTerm
                    HAVING AVG(u1.AskingPrice) > (
                            SELECT AVG(u2.AskingPrice)
                            FROM Unit u2
                    )
                    ';
                    $result = executePlainSQL($query);
                    while ($data = oci_fetch_row($result)) {
                        echo  "LeaseTerm(Days): " . $data[0] . ", MinimumAvgPrice: " . $data[1] . "<br>";
                    }
                ?>
            </div>
        </div>

        <hr />
        <p>Search Results:</p>

        <?php
		//this tells the system that it's no longer just parsing html; it's now parsing PHP

        $success = True; //keep track of errors so it redirects the page only if there are no errors
        $db_conn = NULL; // edit the login credentials in connectToDB()
        $show_debug_alert_messages = False; // set to True if you want alerts to show you which methods are being triggered (see how it is used in debugAlertMessage())



        function redirect($url) {
            header('Location: '.$url);
            die();
        }
        
        // HANDLE ALL GET ROUTES
	    // A better coding practice is to have one method that reroutes your requests accordingly. It will make it easier to add/remove functionality.
        function handleGETRequest() {
            if (connectToDB()) {
                if (array_key_exists('displayUnitsRequest', $_GET)) {
                    handleDisplayRequest();
                }
                disconnectFromDB();
            }
        }
        
        function handleDisplayRequest() {
            global $db_conn;

            $NoBedrooms = $_GET['NoBedrooms']; 
            $NoBathrooms = $_GET['NoBathrooms'];
            // $Furnished = $_GET['Furnished'];
            // $Sublet = $_GET['Sublet'];
            $AskingPrice = $_GET['AskingPrice'];
            
            $result = executePlainSQL("SELECT UnitID, NoBedrooms, NoBathrooms, Address, Furnished, LeaseTerm, Sublet, MoveInDate, AskingPrice, ManagementID 
            FROM Unit WHERE NoBedrooms <= '" . $NoBedrooms . "'  AND NoBathrooms <= '" . $NoBathrooms ."' AND AskingPrice <= '" . $AskingPrice . "'");

            if (oci_fetch_all($result, $rows, null, null, OCI_FETCHSTATEMENT_BY_ROW) > 0) {
                // Start displaying the table or list of results
                echo "<table>";
                echo "<tr style = 'justify'>
                        <th>UnitID</th>
                        <th>NoBedrooms</th>
                        <th>NoBathrooms</th>
                        <th>Address</th>
                        <th>Furnished</th>
                        <th>LeaseTerm</th>
                        <th>Sublet</th>
                        <th>MoveInDate</th>
                        <th>AskingPrice</th>
                        <th>ManagementID</th>
                    </tr>";

                // Iterate over each row in the result
                foreach ($rows as $row) {
                    // Extract the values from the row
                    $unitID = $row['UNITID'];
                    $bedrooms = $row['NOBEDROOMS'];
                    $bathrooms = $row['NOBATHROOMS'];
                    $address = $row['ADDRESS'];
                    $furnished = $row['FURNISHED'];
                    $leaseTerm = $row['LEASETERM'];
                    $sublet = $row['SUBLET'];
                    $moveInDate = $row['MOVEINDATE'];
                    $askingPrice = $row['ASKINGPRICE'];
                    $managementID = $row['MANAGEMENTID'];

                    $url = "unitView.php?unitID=$unitID";

                    // Display the row values in the table
                    echo "<tr onclick='window.location.href=\"$url\";'>
                            <td>$unitID</td>
                            <td>$bedrooms</td>
                            <td>$bathrooms</td>
                            <td>$address</td>
                            <td>$furnished</td>
                            <td>$leaseTerm</td>
                            <td>$sublet</td>
                            <td>$moveInDate</td>
                            <td>$askingPrice</td>
                            <td>$managementID</td>
                        </tr>";
                }

                // Close the table
                echo "</table>";
            } else {
                // No rows found
                echo "No results found.";
            }
        }

        if (isset($_GET['countTupleRequest']) || isset($_GET['displayUnits'])) {
            handleGETRequest();
        }
		?>
	</body>
</html>